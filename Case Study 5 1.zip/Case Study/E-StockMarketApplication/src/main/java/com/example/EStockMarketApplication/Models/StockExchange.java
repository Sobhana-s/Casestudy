package com.example.EStockMarketApplication.Models;

public enum StockExchange {
    NSE,
    BSE
}
